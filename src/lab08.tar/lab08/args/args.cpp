#include <iostream>
using namespace std;


int main(int argc, char *argv[])
{
    cout << "replace this with code that prints all the command line arguments\n";
}
