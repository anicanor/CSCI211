// Simple class that stores a pair of numbers

#ifndef BAR_H
#define BAR_H

class Bar
{
    public:
        Bar(int x, int y);
        void print();
    private:
        int m_x;
        int m_y;
};

#endif
