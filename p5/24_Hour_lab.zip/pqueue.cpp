#include "pqueue.h"
#include "cust.h"

#include<iostream>
using namespace std;

Pqueue::Pqueue()
{
  m_head = NULL; 
  m_tail = NULL;

}


Pqueue::~Pqueue()
{

  Node *ptr = m_head;
  while(ptr != NULL)
  {
    Node *temp;

    temp = ptr;
    ptr = ptr->m_next;
    delete temp;
  }

}
/*
   bool Pqueue::dequeue(Cust *value_removed)
   {
   if(m_head == NULL)
   return false;
   Node *ptr = m_head;
   value_removed = ptr -> m_cust;

   return true;
   }
   */

/*
void Pqueue::enqueue(Cust *cust, int priority)
{
if( !m_head)
{
  m_head = new Node(priority, cust, m_head);
}
if(m_head->m_priority == priority)
  


}*/


void Pqueue::enqueue(Cust *cust, int priority)
{
  if(m_head==NULL || priority < m_head->m_priority)
  {
    m_head = new Node(priority, cust, m_head);
  }
  
  //else if(priority>m_tail->m_priority)
  //{
  // Node *tmp = m_tail;

  
 //    Node *ptr = m_head;
  //   else if(priority >= ptr->m_head->m_priority)
   //  {
    // }
     
  else
  {
    Node *ptr = m_head;
    while((ptr->m_next != NULL) && (ptr->m_next->m_priority <= priority))
    {
      if(ptr->m_next->m_priority==priority)
      {
        ptr->m_next = new Node(priority, cust, ptr->m_next);
      }
      ptr = ptr->m_next;
    }
    ptr->m_next = new Node(priority, cust, ptr->m_next);
  }

}


Cust *Pqueue::dequeue()
{

  if(m_head == NULL)
    return NULL;
  else 
    //for(Node *ptr = m_head; ptr != NULL; ptr=ptr->m_next)
  {
    Node *ptr = m_head;
    return ptr->m_cust;
  } 
}


bool Pqueue::empty()
{

  if(m_head==NULL)
    return true;
  else
    return false;

  //return m_head == NULL;
}

void Pqueue::print()
{
Node *ptr = m_head;
while(ptr != NULL)
{
  ptr->m_cust->print(ostream &os);
  ptr = ptr -> m_next;
}

}
